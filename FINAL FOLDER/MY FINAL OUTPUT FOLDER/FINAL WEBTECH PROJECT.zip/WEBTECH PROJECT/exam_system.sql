CREATE DATABASE  IF NOT EXISTS `exam_system` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `exam_system`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: exam_system
-- ------------------------------------------------------
-- Server version	5.7.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `answers`
--

DROP TABLE IF EXISTS `answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answers` (
  `answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `question` varchar(45) NOT NULL,
  `answer` varchar(45) NOT NULL,
  `correct_answer` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`answer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answers`
--

LOCK TABLES `answers` WRITE;
/*!40000 ALTER TABLE `answers` DISABLE KEYS */;
INSERT INTO `answers` VALUES (37,38,'Prelim','pass','','incorrect'),(38,39,'Prelim','pass','','incorrect');
/*!40000 ALTER TABLE `answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `course_name` varchar(25) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `time` varchar(45) NOT NULL,
  PRIMARY KEY (`course_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES ('Prelim',40,'60');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exams` (
  `exam_id` int(11) NOT NULL AUTO_INCREMENT,
  `std_id` varchar(45) NOT NULL,
  `course_name` varchar(45) NOT NULL,
  `total_marks` varchar(45) NOT NULL,
  `obt_marks` varchar(45) DEFAULT NULL,
  `date` varchar(45) NOT NULL,
  `start_time` varchar(45) NOT NULL,
  `end_time` varchar(45) DEFAULT NULL,
  `exam_time` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES (38,'101','Prelim','40','0','12-12-2018','19:09:24.117','19:09:37.684','60','Fail'),(39,'101','Prelim','40','0','12-12-2018','19:11:32.150','19:21:18.719','60','Fail');
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fillquestions`
--

DROP TABLE IF EXISTS `fillquestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fillquestions` (
  `fillquestion_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(45) NOT NULL,
  `question` varchar(255) NOT NULL,
  `correct` varchar(85) NOT NULL,
  PRIMARY KEY (`fillquestion_id`)
) ENGINE=MyISAM AUTO_INCREMENT=211 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fillquestions`
--

LOCK TABLES `fillquestions` WRITE;
/*!40000 ALTER TABLE `fillquestions` DISABLE KEYS */;
INSERT INTO `fillquestions` VALUES (201,'Prelim','Methods lastIndexOf() returns _____ if text is not found.','-1'),(202,'Prelim','A _______ is an expressions terminated by a semicolon in PHP','statement'),(203,'Prelim','In PHP, variables are denoted with ____________ sign.','dollar'),(204,'Prelim','__________ style in CSS that has the highest precedence closest to the content.','inline'),(205,'Prelim','__________ selector that matches the elements of any type in CSS.','universal'),(206,'Prelim','___________ as software engineer who invented the World Wide Web','Tim Berners-Lee'),(207,'Prelim','In JS, ______ are executed as a plain text without compilation to run.','script'),(208,'Prelim','HTML ______, consists of tags that are enclosed inside an angle bracket','syntax'),(209,'Prelim','In HTML, ______ are not included and it represents entities.','pseudo-elements'),(210,'Prelim','It\'s purpose is to tract and it is stored on the client computer.','cookies');
/*!40000 ALTER TABLE `fillquestions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jumblequestions`
--

DROP TABLE IF EXISTS `jumblequestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jumblequestions` (
  `jumblequestion_id` int(10) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(45) NOT NULL,
  `question` varchar(45) NOT NULL,
  `correct` varchar(45) NOT NULL,
  PRIMARY KEY (`jumblequestion_id`)
) ENGINE=MyISAM AUTO_INCREMENT=311 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jumblequestions`
--

LOCK TABLES `jumblequestions` WRITE;
/*!40000 ALTER TABLE `jumblequestions` DISABLE KEYS */;
INSERT INTO `jumblequestions` VALUES (301,'Prelim','CEERLOTS','SELECTOR'),(302,'Prelim','IEISYCFCITP','SPECIFITY'),(303,'Prelim','SPIARTCVAJ','JAVASCRIPT'),(304,'Prelim','BREATTUITS','ATTRIBUTES'),(305,'Prelim','BTAMSCOOIRN','COMBINATORS'),(306,'Prelim','MEBDEDDE','EMBEDDED'),(307,'Prelim','RESTVLE','SERVLET'),(308,'Prelim','TINOSAUART','SATURATION'),(309,'Prelim','ATNOIMTPR','IMPORTANT'),(310,'Prelim','EWTKBI','WEBKIT');
/*!40000 ALTER TABLE `jumblequestions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matchingquestions`
--

DROP TABLE IF EXISTS `matchingquestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matchingquestions` (
  `matchingquestion_id` int(10) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(45) NOT NULL,
  `question` varchar(225) NOT NULL,
  `op1` varchar(85) NOT NULL,
  `op2` varchar(85) NOT NULL,
  `op3` varchar(85) NOT NULL,
  `op4` varchar(85) NOT NULL,
  `op5` varchar(85) NOT NULL,
  `op6` varchar(85) NOT NULL,
  `op7` varchar(85) NOT NULL,
  `op8` varchar(85) NOT NULL,
  `op9` varchar(85) NOT NULL,
  `op10` varchar(85) NOT NULL,
  `correct` varchar(85) NOT NULL,
  PRIMARY KEY (`matchingquestion_id`)
) ENGINE=MyISAM AUTO_INCREMENT=411 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matchingquestions`
--

LOCK TABLES `matchingquestions` WRITE;
/*!40000 ALTER TABLE `matchingquestions` DISABLE KEYS */;
INSERT INTO `matchingquestions` VALUES (401,'Prelim','RFC stands for','Request for comment','1996','Status code','CSS','Child Combinator','General Sibling combinator','Author style','Inline','Java Servlet Pages','JDBC','Request for commnet'),(402,'Prelim','What year does the firstRFC for HTTP published','Request for comment','1996','Status code','CSS','Child Combinator','General Sibling combinator','Author style','Inline','Java Servlet Pages','JDBC','1996'),(403,'Prelim','Indicate the result of operation','Request for comment','1996','Status code','CSS','Child Combinator','General Sibling combinator','Author style','Inline','Java Servlet Pages','JDBC','Status code'),(404,'Prelim','Used for designing SVG','Request for comment','1996','Status code','CSS','Child Combinator','General Sibling combinator','Author style','Inline','Java Servlet Pages','JDBC','CSS'),(405,'Prelim','What combinator is this >','Request for comment','1996','Status code','CSS','Child Combinator','General Sibling combinator','Author style','Inline','Java Servlet Pages','JDBC','Child Combinator'),(406,'Prelim','What combinator is this ~','Request for comment','1996','Status code','CSS','Child Combinator','General Sibling combinator','Author style','Inline','Java Servlet Pages','JDBC','General Combinator'),(407,'Prelim','What HTML Style Sheets has the highest priority','Request for comment','1996','Status code','CSS','Child Combinator','General Sibling combinator','Author style','Inline','Java Servlet Pages','JDBC','Author Style'),(408,'Prelim','Type of Style Sheets where the design is found inside the element tag','Request for comment','1996','Status code','CSS','Child Combinator','General Sibling combinator','Author style','Inline','Java Servlet Pages','JDBC','Inline Style'),(409,'Prelim','JSP stands for','Request for comment','1996','Status code','CSS','Child Combinator','General Sibling combinator','Author style','Inline','Java Servlet Pages','JDBC','Java Servlet Pages'),(410,'Prelim','Driver used for connecting a java program to dabase','Request for comment','1996','Status code','CSS','Child Combinator','General Sibling combinator','Author style','Inline','Java Servlet Pages','JDBC','JDBC');
/*!40000 ALTER TABLE `matchingquestions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(45) NOT NULL,
  `question` varchar(255) NOT NULL,
  `opt1` varchar(85) NOT NULL,
  `opt2` varchar(85) NOT NULL,
  `opt3` varchar(85) NOT NULL,
  `opt4` varchar(85) NOT NULL,
  `correct` varchar(85) NOT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (8,'Prelim','What is the most common way of adding style is to use?','External Styling','Inline Styling','Internal Styling','Outline Styling','External Styling'),(9,'Prelim','Starting from what part of declaration does the HTML document is visible?','p','html','body','br','body'),(10,'Prelim','The HSL value in HTML (colors) means?','High, Stable, Low','Hue, Saturated, Low','Hue, Saturation, Light','High, Stable, Light','Hue, Saturation, Light'),(11,'Prelim','The element <  em  > in HTML defines?','Exponential mode','Emphasized text','Italicize text','Strong text','Emphasized text'),(12,'Prelim','In HTML, the element <  abbr  > defines?','Citation','Acronym','Abbreviation','None of the above','Acronym'),(14,'Prelim','Initially the HyperText Markup Language was discovered in what year?','1991','1998','1976','1990','1990'),(15,'Prelim','The abbreviation of NaN is?','Not a name','Not a number','Not a noun','None of the above','Not a number'),(16,'Prelim','What is the color of unvisited links in HTML?','Green','Blue','Red','Orange','Blue'),(18,'Prelim','What is the filename extension when saving a cascading style sheet?','.css','.cs','.html','.csv','.css');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `user_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `user_type` varchar(45) NOT NULL,
  `contact_no` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8 COMMENT='		';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (101,'Leo','Dion','2161824','2161824@gmail.com','example','student','09652316030','Baguio','Bakakeng'),(102,'Michael','Pinto','2000600','2000600@gmail.com','sample','admin','09653203001','Baguio','Town'),(107,'Juan','Dela Cruz','juan','juan@gmail.com','password','student','09568932561','Manila','Mandaluyong');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-13  7:22:28
