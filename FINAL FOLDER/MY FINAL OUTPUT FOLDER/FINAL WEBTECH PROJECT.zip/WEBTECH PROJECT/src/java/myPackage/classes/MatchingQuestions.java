package myPackage.classes;

public class MatchingQuestions {

    private int questionId;
    private String question;
    private String opt1, opt2, opt3, opt4, opt5, opt6, opt7, opt8, opt9, opt10;
    private String correct, courseName;

    public MatchingQuestions(int questionId, String question,
            String opt1, String opt2, String opt3, String opt4, String opt5, String opt6, String opt7, String opt8, String opt9, String opt10,
            String correct, String courseName) {
        this.questionId = questionId;
        this.question = question;
        this.opt1 = opt1;
        this.opt2 = opt2;
        this.opt3 = opt3;
        this.opt4 = opt4;
        this.opt5 = opt5;
        this.opt6 = opt6;
        this.opt7 = opt7;
        this.opt8 = opt8;
        this.opt9 = opt9;
        this.opt10 = opt10;
        this.correct = correct;
        this.courseName = courseName;
    }

    /**
     * @return the questionId
     */
    public int getQuestionId() {
        return questionId;
    }

    /**
     * @param questionId the questionId to set
     */
    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }

    /**
     * @return the question
     */
    public String getQuestion() {
        return question;
    }

    /**
     * @param question the question1 to set
     */
    public void setQuestion(String question1) {
        this.question = question;
    }

    /**
     * @return the opt1
     */
    public String getOpt1() {
        return opt1;
    }

    /**
     * @param opt1 the opt1 to set
     */
    public void setOpt1(String opt1) {
        this.opt1 = opt1;
    }

    /**
     * @return the opt2
     */
    public String getOpt2() {
        return opt2;
    }

    /**
     * @param opt2 the opt2 to set
     */
    public void setOpt2(String opt2) {
        this.opt2 = opt2;
    }

    /**
     * @return the opt3
     */
    public String getOpt3() {
        return opt3;
    }

    /**
     * @param opt3 the opt3 to set
     */
    public void setOpt3(String opt3) {
        this.opt3 = opt3;
    }

    /**
     * @return the opt4
     */
    public String getOpt4() {
        return opt4;
    }

    /**
     * @param opt4 the opt4 to set
     */
    public void setOpt4(String opt4) {
        this.opt4 = opt4;
    }

    /**
     * @return the opt5
     */
    public String getOpt5() {
        return opt5;
    }

    /**
     * @param opt5 the opt5 to set
     */
    public void setOpt5(String opt5) {
        this.opt5 = opt5;
    }

    /**
     * @return the opt6
     */
    public String getOpt6() {
        return opt6;
    }

    /**
     * @param opt6 the opt6 to set
     */
    public void setOpt6(String opt6) {
        this.opt6 = opt6;
    }

    /**
     * @return the opt7
     */
    public String getOpt7() {
        return opt7;
    }

    /**
     * @param opt7 the opt7 to set
     */
    public void setOpt7(String opt7) {
        this.opt7 = opt7;
    }

    /**
     * @return the opt8
     */
    public String getOpt8() {
        return opt8;
    }

    /**
     * @param opt8 the opt8 to set
     */
    public void setOpt8(String opt8) {
        this.opt8 = opt8;
    }

    /**
     * @return the opt9
     */
    public String getOpt9() {
        return opt9;
    }

    /**
     * @param opt9 the opt9 to set
     */
    public void setOpt9(String opt9) {
        this.opt9 = opt9;
    }

    /**
     * @return the opt10
     */
    public String getOpt10() {
        return opt10;
    }

    /**
     * @param opt10 the opt10 to set
     */
    public void setOpt10(String opt10) {
        this.opt10 = opt10;
    }

    /**
     * @return the correct
     */
    public String getCorrect() {
        return correct;
    }

    /**
     * @param correct the correct to set
     */
    public void setCorrect(String correct) {
        this.correct = correct;
    }

    /**
     * @return the courseName
     */
    public String getCourseName() {
        return courseName;
    }

    /**
     * @param courseName the courseName to set
     */
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

}
