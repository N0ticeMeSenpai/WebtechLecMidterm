CREATE DATABASE  IF NOT EXISTS `webtechfinals` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `webtechfinals`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: webtechfinals
-- ------------------------------------------------------
-- Server version	5.7.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fill_questionnaires`
--

DROP TABLE IF EXISTS `fill_questionnaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fill_questionnaires` (
  `fill_id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(45) NOT NULL,
  `answer` varchar(45) NOT NULL,
  PRIMARY KEY (`fill_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fill_questionnaires`
--

LOCK TABLES `fill_questionnaires` WRITE;
/*!40000 ALTER TABLE `fill_questionnaires` DISABLE KEYS */;
/*!40000 ALTER TABLE `fill_questionnaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jumble_questionnaires`
--

DROP TABLE IF EXISTS `jumble_questionnaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jumble_questionnaires` (
  `jumble_id` int(11) NOT NULL AUTO_INCREMENT,
  `jumble_word` varchar(45) NOT NULL,
  `answer` varchar(45) NOT NULL,
  PRIMARY KEY (`jumble_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jumble_questionnaires`
--

LOCK TABLES `jumble_questionnaires` WRITE;
/*!40000 ALTER TABLE `jumble_questionnaires` DISABLE KEYS */;
/*!40000 ALTER TABLE `jumble_questionnaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matching_questionnaires`
--

DROP TABLE IF EXISTS `matching_questionnaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matching_questionnaires` (
  `matching_id` int(11) NOT NULL AUTO_INCREMENT,
  `table1` varchar(45) NOT NULL,
  `table2` varchar(45) NOT NULL,
  `answer` varchar(45) NOT NULL,
  PRIMARY KEY (`matching_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matching_questionnaires`
--

LOCK TABLES `matching_questionnaires` WRITE;
/*!40000 ALTER TABLE `matching_questionnaires` DISABLE KEYS */;
/*!40000 ALTER TABLE `matching_questionnaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multiple_questionnaires`
--

DROP TABLE IF EXISTS `multiple_questionnaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multiple_questionnaires` (
  `multiple_id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(45) NOT NULL,
  `choices` varchar(45) NOT NULL,
  `answer` varchar(45) NOT NULL,
  PRIMARY KEY (`multiple_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multiple_questionnaires`
--

LOCK TABLES `multiple_questionnaires` WRITE;
/*!40000 ALTER TABLE `multiple_questionnaires` DISABLE KEYS */;
/*!40000 ALTER TABLE `multiple_questionnaires` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-01 17:30:38
