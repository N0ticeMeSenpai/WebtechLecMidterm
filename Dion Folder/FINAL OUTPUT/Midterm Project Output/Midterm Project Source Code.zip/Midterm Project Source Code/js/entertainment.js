const vm = new Vue({
    el: '#entertainment',
    data: {
        articles: []
    },
    mounted() {
        axios.get("https://newsapi.org/v2/top-headlines?country=ph&category=entertainment&apiKey=65b04b44f0a94620b396b7e23ed957a9")
            .then(response => {
                this.articles = response.data.articles
            })
    }
});
