new Vue({
    el: '#headlines',
    data: {
        articles: [
            {
                author: "TDG",
                title: "P23M flood control structure constructed in Guimaras town",
                url: "https://thedailyguardian.net/community-news/p23m-flood-control-structure-constructed-in-guimaras-town/",
                urlToImage: "https://thedailyguardian.net/wp-content/uploads/2018/11/floodcontrol.jpg",
                publishedAt: "2018-11-18T19:30:54Z",
                sourcename: "Thedailyguardian.net"
            },
            {
                author: "Terray Sylvester",
                title: "UPDATE 2-Grim search for 1276 missing after deadliest California wildfire",
                url: "https://www.reuters.com/article/california-wildfires/update-2-grim-search-for-1276-missing-after-deadliest-california-wildfire-idUSL2N1XT076",
                urlToImage: "https://s2.reutersmedia.net/resources/r/?m=02&d=20181118&t=2&i=1326432843&w=1200&r=LYNXNPEEAH06D",
                publishedAt: "2018-11-18T18:41:00Z",
                sourcename: "Reuters"
            },
            {
                author: "bw_mark",
                title: "DoE to launch new energy contracting round this week",
                url:"https://www.bworldonline.com/doe-to-launch-new-energy-contracting-round-this-week/",
                urlToImage: "https://www.bworldonline.com/wp-content/uploads/2018/03/DoE-032818.jpg",
                publishedAt: "2018-11-18T15:10:58Z",
                sourcename: "Bworldonline.com"
            }
        ]
    }
});
