const vm = new Vue({
    el: '#latest',
    data: {
       posts: []
    },
    mounted() {
        axios.get("http://webhose.io/filterWebContent?token=a5d2b8a9-4239-44f6-8753-065ec9944910&format=json&ts=1542498052971&sort=published&q=stock%20market%20language%3Aenglish")
            .then(response => {
                this.posts = response.data.posts
            })
    }
});
